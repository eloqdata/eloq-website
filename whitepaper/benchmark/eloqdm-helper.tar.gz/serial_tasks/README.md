### How to start
Install command tool `jq`
```shell
# centos
sudo yum install jq
# ubuntu
sudo apt install jq
```
Add `dmctl` to `PATH`
```shell
export PATH=$PATH:<path/to/dmctl>
```
Edit the task config template file `task_temp.yaml`.  
```shell
vim task_temp.yaml
```
Execute it
```shell
# Maybe you need to edit `MASTER_ADDR` in this script
./serial.sh # use tmux

# or
nohup ./serial.sh > out.txt 2>&1 &
tail -f out.txt
```
### How to recovery
1. Stop the last errored task
2. Drop the created but not finished table in target database. 
3. Re-run `./serial.sh` .
